package com.example.ilhmndn.homepage5;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * Created by Ilhmndn on 3/12/2018.
 */

public class CustomSwipeAdapter2 extends PagerAdapter {
    private int[] image_resources2 = {R.drawable.hactiv,R.drawable.ikiki,R.drawable.keke,R.drawable.koko};
    private Context ctx2;
    private LayoutInflater layoutInflater2;

    public CustomSwipeAdapter2(Context ctx){
        this.ctx2 = ctx;
    }


    @Override
    public int getCount() {
        return image_resources2.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return (view==(LinearLayout)object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        layoutInflater2 = (LayoutInflater)ctx2.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item_view = layoutInflater2.inflate(R.layout.swipe_layout2,container,false);
        ImageView imageView = (ImageView) item_view.findViewById(R.id.image_view2);
        imageView.setImageResource(image_resources2[position]);
        container.addView(item_view);
        return item_view;


    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout)object);
    }
}