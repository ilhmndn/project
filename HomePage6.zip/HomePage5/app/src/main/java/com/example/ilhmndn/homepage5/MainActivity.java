package com.example.ilhmndn.homepage5;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    ViewPager viewPager, viewPager2;
    CustomSwipeAdapter adapter;
    CustomSwipeAdapter2 adapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = (ViewPager)findViewById(R.id.view_pager);
        adapter = new CustomSwipeAdapter(this);
        viewPager.setAdapter(adapter);


        viewPager2 = (ViewPager)findViewById(R.id.view_pager2);
        adapter2 = new CustomSwipeAdapter2(this);
        viewPager2.setAdapter(adapter2);
    }
}
